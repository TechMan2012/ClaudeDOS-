# How the text editor's raw keystroke input works

Every other screen in the menu uses BusyBox ash's normal, line-buffered
`read` -- type a line, press Enter, the whole line arrives at once. That's
fine for "type a number and press Enter" style menus, but wrong for a text
editor: you want each keystroke to register immediately (so Backspace
works, so Enter creates a new line without ending the whole input).

## The mechanism

Two pieces, both real BusyBox applets, no external dependencies:

**1. `stty raw -echo`** -- puts the terminal into raw mode. This does two
things:
- Disables canonical/line-buffered input (normally the kernel's terminal
  driver buffers a whole line and hands it to a reading process only after
  Enter; raw mode hands over bytes as they arrive)
- Disables local echo (normally the terminal driver automatically prints
  back what you type; with echo off, the *program* is responsible for
  deciding what to display)

**2. `dd bs=1 count=1`** -- reads exactly one byte from stdin per call.
Combined with raw mode, this reads one keystroke at a time.

```sh
c=$(dd bs=1 count=1 2>/dev/null)
```

The `2>/dev/null` matters -- `dd` writes its own transfer summary
(`1+0 records in` / `1+0 records out`) to stderr on every single call.
Without suppressing that, it leaks into the captured character. (This was
a real bug hit while building this -- see `DEBUGGING-NOTES.md`.)

## The main loop

```sh
ENTER=$(printf '\r')
BACKSPACE=$(printf '\177')
CTRLS=$(printf '\023')
CTRLX=$(printf '\030')

stty raw -echo
while true; do
    c=$(dd bs=1 count=1 2>/dev/null)
    case "$c" in
        "$ENTER")     buf="${buf}
"; printf '\r\n' ;;
        "$BACKSPACE") buf="${buf%?}"; printf '\b \b' ;;
        "$CTRLS")     printf "%s" "$buf" > "$file" ;;
        "$CTRLX")     stty sane; return ;;
        *)            buf="${buf}${c}"; printf "%s" "$c" ;;
    esac
done
```

A few things worth explaining:

- **Enter arrives as `\r` (carriage return), not `\n`.** Raw mode disables
  the terminal driver's usual CR->LF translation, so what actually comes
  in from the Enter key is a raw `\r` (0x0D). The buffer stores an actual
  newline character (`\n`) internally so the saved file is normal,
  Unix-line-ending text.

- **Backspace is 0x7F (DEL), not 0x08.** This is what the Linux console
  actually sends for the Backspace key (confirmed via `stty -a`, which
  reports `erase = ^?`). Erasing on screen is the classic terminal trick:
  print backspace, then a space (to blank the character), then backspace
  again (`\b \b`) to leave the cursor in the right place.

- **`buf="${buf%?}"` removes exactly the last character**, using POSIX
  parameter expansion (`%?` = shortest match of any single trailing
  character). This works correctly even if the last character was a
  newline from a previous Enter press -- but see the known limitation
  below.

- **Ctrl+S and Ctrl+X are literal control-character bytes** (0x13 and
  0x18), built with `printf '\023'` / `printf '\030'` and compared via
  `case` pattern matching against the captured byte. Since these are
  non-printable control codes, they can never collide with anything
  someone actually types.

- **Everything else falls into the catch-all `*`** and just gets appended
  to the buffer and echoed back -- this is what makes normal typing work
  at all, since local echo is off.

## Known limitation: Backspace across a line boundary

If you backspace at the very start of a line (removing the newline
character that separated it from the previous line), the buffer is
correctly updated -- but the on-screen cursor doesn't actually move up a
row, since `\b \b` only operates within the current line. The underlying
saved content will still be correct; the live *display* just won't look
perfectly clean in that specific edge case. Fixing this properly would
need cursor position tracking and `ESC[A` (cursor-up) sequences.

## Known limitation: no arrow keys

Arrow keys send multi-byte escape sequences (e.g. `ESC [ A` for up). Since
this reads one raw byte at a time with no escape-sequence state machine,
pressing an arrow key just inserts those three bytes as if they were
(invisible/garbage) typed characters, rather than moving the cursor. Not
handled -- out of scope for how simple this was meant to be, but a natural
next step if someone wants to extend it.

## Restoring normal mode

`stty sane` on Ctrl+X (and after Ctrl+S's "[Saved]" message) is essential
-- without it, the terminal stays in raw/no-echo mode after returning to
the menu, and the rest of the menu system (which relies on normal
line-buffered `read`) would break. This was tested explicitly: exit the
editor, then confirm the surrounding menu still responds normally to
plain typed input afterward.
