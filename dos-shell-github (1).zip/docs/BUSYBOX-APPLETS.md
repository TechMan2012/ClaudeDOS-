# Why these specific BusyBox applets

BusyBox is one statically-linked binary that behaves differently depending
on the name it's invoked as (`argv[0]`) -- that's why the initramfs is full
of symlinks all pointing at the same `busybox` file. Nothing is available
unless it's explicitly symlinked; there's no `$PATH` fallback to a "real"
version of anything.

| Command | Used for |
|---|---|
| `sh` | The shell itself -- runs `dosshell` and everything else |
| `ls`, `cat`, `mkdir`, `cp`, `mv`, `rm` | File Manager, general file ops |
| `echo`, `printf` | All screen output/menu rendering |
| `mount`, `umount`, `mknod` | Mounting `/proc`, `/sys`, `/dev` at boot |
| `ln` | Building the symlink farm itself, and used in scripts |
| `clear` | Screen clears between menu screens |
| `uname` | Kernel version shown in banner and About screen |
| `free`, `df` | System Info screen |
| `dmesg` | Available at the command prompt for diagnostics |
| `poweroff`, `reboot`, `halt` | Shut Down menu option |
| `stty` | Terminal mode control -- both `cttyhack`'s use and the raw-mode text editor |
| `vi` | Left in as a fallback/available editor at the command prompt (the menu's own Text Editor doesn't use it -- see `RAW-INPUT-EDITOR.md`) |
| `date` | Live clock, and uptime calculation |
| `sleep` | Boot banner timing, various UI pauses |
| `cd`, `wc` | General shell utility |
| `setsid`, `cttyhack` | Properly attaching a controlling TTY -- see `DEBUGGING-NOTES.md` |
| `insmod` | Manually loading the three keyboard driver modules at boot |
| `grep`, `cut`, `sed`, `awk` | Parsing `/proc/cpuinfo`, `/proc/meminfo` for the About screen; line editing in the (now-retired) line-based editor |
| `hostname` | About screen |
| `head` | Used in a few places for trimming output |
| `kill` | Was used for the background-clock-process approach to the live clock; that approach was abandoned (see `DEBUGGING-NOTES.md`) but the applet is harmless to leave available |
| `dd` | Raw single-keystroke capture in the text editor (`dd bs=1 count=1`) |
| `basename`, `dirname` | Directory tree walking / `..` navigation in File Manager |

## What's deliberately *not* here

No GNU coreutils, no `bash`, no `systemd`, no `udev` (beyond the specific
kernel modules needed for keyboard input), no networking tools, no
package manager. Anything not in this list simply doesn't exist at
runtime -- there's no fallback.
